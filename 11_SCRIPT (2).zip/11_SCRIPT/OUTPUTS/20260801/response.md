# PART 1 — TITLE

The Cost of Truth and the Price of Grace

# PART 2 — SCRIPTURE

Reading I:
Jeremiah 26:11-16.24

Gospel:
Matthew 14:1-12

# PART 3 — THEME

True faithfulness to God often requires the courage to stand alone against the currents of the world, following the pattern of Christ, who remains steadfast in His mission even when the world responds with rejection and injustice.

# PART 4 — HISTORICAL BACKGROUND

In the time of Jeremiah, the religious and political leaders of Judah were deeply invested in maintaining the status quo to please the ruling elite and preserve social stability. To preach repentance was seen as treasonous to the state. Similarly, in the Gospel, Herod Antipas is portrayed as a man caught between his conscience and his public image. His banquet is not merely a social gathering but a display of power, where personal reputation and political convenience carry more weight than justice or the dignity of life.

# PART 5 — SCRIPTURE MEDITATION

(Begin with a slow, ambient, cinematic atmosphere)

The air in the courtyard is thick with tension. In one corner, a prophet stands alone, his voice trembling not with fear, but with the weight of a message he did not choose, yet cannot deny. Jeremiah looks into the eyes of the priests and the kings, men who hold power, and tells them a truth that tastes like ash: *Repent, or be destroyed.* He stands in the gap between a holy God and a people drifting into darkness, knowing that the truth will not be met with applause, but with hostility.

(Transition to a softer, more somber tone)

Across the landscape of the Gospels, we see a different kind of truth being silenced. Under the dim lights of a banquet hall, Herod Antipas feasts. There is music, fine wine, and the hollow laughter of men who believe they are in control. But beneath the celebration lies a fractured soul. To save face before his guests, a young woman’s life is traded for a fleeting moment of pride. A daughter’s dance becomes a death sentence, and the conscience of a ruler is sacrificed on the altar of social standing.

Can you hear the echoes of these two stories?

In Jeremiah, we see the cost of speaking God’s word. In Herod, we see the cost of denying it.

One man risks his life to speak the truth; another destroys a life to hide his compromise. One follows the narrow path of righteousness; the other follows the wide path of worldly convenience.

As we sit in the silence of this moment, Jesus is watching us. He is the one who stood before Pilate, the ultimate King, who spoke the Truth of Love while the world demanded a spectacle. He is the one who was betrayed for thirty pieces of silver, yet never turned away from the mission of our salvation. He is the Lamb who was slain so that we might finally live.

Close your eyes. Imagine yourself in that courtyard. Imagine yourself at that banquet. Where are you standing? Are you clinging to the safety of the crowd, or are you willing to stand with the prophet? Are you protecting your reputation, or are you protecting the dignity of the person before you?

The world will always ask you to silence your conscience to keep the peace. But Christ calls you to a peace that only comes from the Truth. He does not ask for your perfection; He asks for your courage to be His.

# PART 6 — LIFE APPLICATION

- **Courage in Conviction:** Identify one area in your life where you feel pressured to stay silent about your faith or your values to avoid social discomfort. Pray for the strength to stand firm.
- **The Trap of Reputation:** Reflect on whether you make decisions based on what God requires or on what will make you look "good" or "successful" in the eyes of others.
- **Protecting the Vulnerable:** In the spirit of the Gospel, look for those "unseen" people in your circles—those without social power—and seek to honor and defend them.
- **Trusting the Prophet's Path:** When you feel rejected for doing what is right, remember Jeremiah. Trust that God’s approval is more enduring than the applause of the world.

# PART 7 — PRAYER

Lord Jesus, You are the Truth that sets us free, yet the world often meets Your truth with rejection. 

Give us the heart of Jeremiah—a heart that is courageous enough to speak Your word even when it is unpopular. Give us the grace to prioritize Your kingdom over our reputation.

Forgive us, Lord, for the times we have acted like Herod, sacrificing our integrity and the dignity of others to satisfy our pride or to avoid embarrassment. Cleanse our hearts of the fear of man.

May we find our security not in the approval of the world, but in being known and loved by You. Help us to walk the path of righteousness, even when it is lonely, knowing that You are walking beside us always.

Amen.

# PART 8 — KEY TAKEAWAYS

- The Truth of God demands a response of courage.
- Seeking human approval often leads to the betrayal of our conscience.
- Real peace is found in alignment with God, not in avoiding conflict.
- Christ is the ultimate fulfillment of the righteous life.